from microbit import *
	

	name = 'Kevin'
	

	while True:
	    display.scroll('Hi ' + name + '!')