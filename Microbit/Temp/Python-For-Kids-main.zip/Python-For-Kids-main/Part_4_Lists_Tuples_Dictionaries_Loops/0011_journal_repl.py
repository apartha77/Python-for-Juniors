journal = [
    {
        'entry': 'Today I started an amazing new journey with MicroPython!',
        'date': '12/15/20',
    },
    {
        'entry': 'Today I created my first app!',
        'date': '12/16/20',
    }
]

new_journal_entry = {}

new_journal_entry['entry'] = 'Today I created my first dictionary!'
new_journal_entry['date'] = '01/15/21'
journal.append(new_journal_entry)

print(journal)