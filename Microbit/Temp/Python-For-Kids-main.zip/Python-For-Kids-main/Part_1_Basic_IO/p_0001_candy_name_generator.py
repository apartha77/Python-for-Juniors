candy_title = input('What is the candy title? ')
candy_flavor = input('What is the candy flavor? ')

print('It shall be called {0} {1}!'.format(candy_title, candy_flavor))
