from microbit import display

display.scroll('Hello World!')
