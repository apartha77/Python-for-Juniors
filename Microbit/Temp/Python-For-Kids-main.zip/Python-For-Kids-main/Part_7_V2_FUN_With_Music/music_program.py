from music import *
	

	play(NYAN)