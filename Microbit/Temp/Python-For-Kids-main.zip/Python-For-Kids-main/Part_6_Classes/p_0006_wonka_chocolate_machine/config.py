CHOICES = ('dark', 'caramel', 'mint', 'surprise', 'stats', 'shutdown')
MAX_VALUE = 100.00
