questions = {
    'What year was the MicroBit educational foundation created?':
        [
            '2016',
            '2014',
            '2017',
            0
        ],
    'What year was the first computer invented?':
        [
            '1954',
            '1943',
            '1961',
            1
        ],
    'What year did Damien George create MicroPiethon?':
        [
            '2015',
            '2012',
            '2014',
            2
        ],
    'What year did the Commodore 64 get released?':
        [
            '1983',
            '1984',
            '1982',
            2
        ],
}
