from microbit import pin2

pin2.set_touch_mode(pin2.CAPACITIVE)
