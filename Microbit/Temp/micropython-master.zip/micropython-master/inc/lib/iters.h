
#include "py/runtime.h"

mp_obj_t microbit_repeat_iterator(mp_obj_t iterable);
