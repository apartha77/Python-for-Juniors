Tests
=====

This directory contains script[s] that can be used to confirm various features
of the micro:bit are working. They are as follows:

* `exercise.py` - a general exercise of various aspects of the hardware. Not exhaustive and requires the user to press buttons A or B to move forward in the tests. Completes with a smile.
* ??? - TBC

